import heapq

def dijkstra():
    n = int(input("Enter number of nodes: "))
    
    # Taking input for the adjacency matrix
    print("Enter adjacency matrix (enter -1 if no edge exists):")
    graph = []
    
    # Reading the adjacency matrix (graph)
    for i in range(n):
        row = list(map(int, input().split()))
        graph.append(row)
    
    start = int(input("Enter the source node: "))

    # Initialize distances and previous node arrays
    dist = [float('inf')] * n
    dist[start] = 0
    prev = [None] * n
    
    # Priority queue to process nodes with the smallest distance first
    pq = [(0, start)]  # (distance, node)
    
    while pq:
        current_dist, current_node = heapq.heappop(pq)
        
        # Skip if we've already processed this node with a shorter path
        if current_dist > dist[current_node]:
            continue
        
        # Check each neighbor of the current node
        for neighbor in range(n):
            if graph[current_node][neighbor] != -1:  # There's an edge
                new_dist = current_dist + graph[current_node][neighbor]
                
                if new_dist < dist[neighbor]:
                    dist[neighbor] = new_dist
                    prev[neighbor] = current_node
                    heapq.heappush(pq, (new_dist, neighbor))
    
    # Reconstruct the path for each node
    paths = []
    for target in range(n):
        path = []
        node = target
        while node is not None:
            path.insert(0, node)
            node = prev[node]
        paths.append(path)
    
    # Print results
    for i in range(n):
        print(f"Distance to node {i}: {dist[i]}")
        print(f"Path: {'->'.join(map(str, paths[i]))}")

# Running the Dijkstra's algorithm
dijkstra()
