import re
class ASTNode:
    """A class representing a node in the Abstract Syntax Tree."""
    def __init__(self, value, left=None, right=None):
        self.value = value  # Operator or operand
        self.left = left    # Left child
        self.right = right  # Right child

class MachineCodeGenerator:
    def __init__(self):
        self.instructions = []
        self.register_counter = 0

    def generate_register(self):
        """Generate a new register."""
        reg = f"R{self.register_counter}"
        self.register_counter += 1
        return reg

    def generate_machine_code(self, node):
        """
        Traverse the AST and generate machine code.
        Returns the register containing the result of the computation.
        """
        if node is None:
            return None

        if node.left is None and node.right is None:
            # Leaf node (operand)
            reg = self.generate_register()
            self.instructions.append(f"MOV {reg}, {node.value}")
            return reg

        # Recursively generate code for left and right subtrees
        left_reg = self.generate_machine_code(node.left)
        right_reg = self.generate_machine_code(node.right)

        # Allocate a new register for the result
        result_reg = self.generate_register()

        # Generate the instruction based on the operator
        if node.value == '+':
            self.instructions.append(f"ADD {result_reg}, {left_reg}, {right_reg}")
        elif node.value == '-':
            self.instructions.append(f"SUB {result_reg}, {left_reg}, {right_reg}")
        elif node.value == '*':
            self.instructions.append(f"MUL {result_reg}, {left_reg}, {right_reg}")
        elif node.value == '/':
            self.instructions.append(f"DIV {result_reg}, {left_reg}, {right_reg}")
        else:
            raise ValueError(f"Unsupported operator: {node.value}")

        # Return the register containing the result
        return result_reg

    def display_machine_code(self):
        """Print the generated machine code."""
        print("Generated Machine Code:")
        for instruction in self.instructions:
            print(instruction)


def parse_expression(expression):
    # Regular expression to match basic operators and operands (variables)
    tokens = re.findall(r'[a-zA-Z]+|\d+|[+\-*/^()]', expression)

    def parse_tokens(tokens):
        if not tokens:
            return None, tokens

        token = tokens.pop(0)
        
        if token.isalpha():  # variable (e.g., 'a')
            return ASTNode(token), tokens
        elif token.isdigit():  # number (e.g., '5')
            return ASTNode(token), tokens
        elif token == '(':  # Start of a sub-expression
            left_node, tokens = parse_tokens(tokens)
            op = tokens.pop(0)  # Operator
            right_node, tokens = parse_tokens(tokens)
            assert tokens.pop(0) == ')'  # Closing parenthesis
            return ASTNode(op, left_node, right_node), tokens
        else:
            return None, tokens

    ast, _ = parse_tokens(tokens)
    return ast

if __name__ == "__main__":
    expression = input("Enter a mathematical expression: ")
    
    # Parse the user input into an AST
    ast = parse_expression(expression)

    # Generate machine code from the AST
    generator = MachineCodeGenerator()
    generator.generate_machine_code(ast)
    
    # Display the machine code
    generator.display_machine_code()