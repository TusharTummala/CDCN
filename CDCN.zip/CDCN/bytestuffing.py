def byte_stuffing(data, flag="F", escape="E"):
    stuffed_data = ""

    for byte in data:
        if byte == flag or byte == escape:
            # Insert escape character before flag or escape character
            stuffed_data += escape + byte
        else:
            stuffed_data += byte

    # Add flag at start and end
    stuffed_data = flag + stuffed_data + flag
    return stuffed_data

def byte_destuffing(stuffed_data, flag="F", escape="E"):
    # Remove starting and ending flags
    if not (stuffed_data.startswith(flag) and stuffed_data.endswith(flag)):
        print("Error: Data does not have valid flags.")
        return None

    destuffed_data = ""
    inside_frame = stuffed_data[1:-1]  # Strip start and end flags
    skip_next = False

    for i in range(len(inside_frame)):
        if skip_next:
            skip_next = False
            continue

        if inside_frame[i] == escape:
            skip_next = True
            continue

        destuffed_data += inside_frame[i]

    return destuffed_data

if __name__ == "__main__":
    # User input
    data = input("Enter data for byte stuffing (string format): ")

    # Default flag and escape characters
    flag = "F"
    escape = "E"

    # Perform byte stuffing
    stuffed = byte_stuffing(data, flag, escape)
    print("Byte-stuffed data:", stuffed)

    # Perform byte destuffing
    destuffed = byte_destuffing(stuffed, flag, escape)
    if destuffed is not None:
        print("Byte-destuffed data:", destuffed)

        # Verify correctness
        if destuffed == data:
            print("Byte destuffing successful. Original data matches destuffed data.")
        else:
            print("Byte destuffing failed. Original data does not match destuffed data.")
