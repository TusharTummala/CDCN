from collections import defaultdict
import re

def tokenize(input_string):
    token_specification = [
        ('ID', r'id'),  # Identifier
        ('PLUS', r'\+'),  # Plus symbol
        ('STAR', r'\*'),  # Multiplication symbol
        ('LPAREN', r'\('),  # Left parenthesis
        ('RPAREN', r'\)'),  # Right parenthesis
        ('END', r'\$'),  # End of input
    ]
    token_regex = '|'.join(f'(?P<{pair[0]}>{pair[1]})' for pair in token_specification)
    tokens = [match.group() for match in re.finditer(token_regex, input_string)]
    return tokens

# Function to calculate First sets
def calculate_first(grammar):
    first = defaultdict(set)
    
    def compute_first(symbol):
        if symbol not in grammar:  # Terminal
            first[symbol].add(symbol)  # Terminals should have themselves in First
            return {symbol}
        if first[symbol]:  # Already computed
            return first[symbol]
        for production in grammar[symbol]:
            for prod_symbol in production:
                if prod_symbol == symbol:  # Avoid infinite recursion
                    continue
                first[symbol].update(compute_first(prod_symbol))
                if '$' not in first[prod_symbol]:  # Stop if no epsilon
                    break
            else:
                first[symbol].add('$')  # Add $ if all symbols derive it
        return first[symbol]
    
    # Compute First for all symbols
    for non_terminal in grammar:
        compute_first(non_terminal)
    
    # Ensure terminals also have their First sets
    for symbol in grammar.keys():
        for production in grammar[symbol]:
            for term in production:
                if term not in grammar:
                    first[term].add(term)
    
    return first

# Function to calculate Follow sets
def calculate_follow(grammar, start_symbol, first):
    follow = defaultdict(set)
    follow[start_symbol].add('$')
    def compute_follow():
        updated = False
        for non_terminal, productions in grammar.items():
            for production in productions:
                trailer = follow[non_terminal].copy()
                for symbol in reversed(production):
                    if symbol in grammar:  # Non-terminal
                        if trailer - follow[symbol]:
                            follow[symbol].update(trailer)
                            updated = True
                        if '$' in first[symbol]:
                            trailer.update(first[symbol] - {'$'})
                        else:
                            trailer = first[symbol]
                    else:  # Terminal
                        trailer = {symbol}
        return updated
    while compute_follow():
        pass
    return follow

def get_grammar_from_user():
    # Number of grammar productions
    num_lines = int(input("Enter the number of grammar productions: "))
    
    # User input for grammar rules
    grammar = {}
    for _ in range(num_lines):
        production_input = input("Enter production in the form 'NonTerminal -> RHS': ")
        left, right = production_input.split('->')
        left = left.strip()
        right = right.strip().split('|')
        if left not in grammar:
            grammar[left] = []
        for prod in right:
            grammar[left].append(prod.split())
    
    # Start symbol input
    start_symbol = input("Enter the start symbol: ").strip()
    
    return grammar, start_symbol


# Main function to run the entire process
if __name__ == "__main__":
    # Get grammar and start symbol from the user
    grammar, start_symbol = get_grammar_from_user()
    
    # Calculate First and Follow sets
    first = calculate_first(grammar)
    follow = calculate_follow(grammar, start_symbol, first)
    # Print results
    print("First:")
    for non_terminal, first_set in first.items():
        print(f"{non_terminal}: {first_set}")

    print("\nFollow:")
    for non_terminal, follow_set in follow.items():
        print(f"{non_terminal}: {follow_set}")
    
 
