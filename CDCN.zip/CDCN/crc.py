def parse_polynomial(poly):
    # If the polynomial is already in binary format, return it directly
    if all(c in "01" for c in poly):
        return poly
    
    # Convert polynomial in x format (e.g., x^4 + x^2 + 1) to binary
    poly = poly.replace(" ", "").split("+")
    highest_power = max(int(t.split("^")[1]) if "^" in t else 1 if "x" in t else 0 for t in poly)
    binary = ['0'] * (highest_power + 1)

    for t in poly:
        if t == "1":
            binary[-1] = '1'
        elif "x" in t:
            power = int(t.split("^")[1]) if "^" in t else 1
            binary[-(power + 1)] = '1'

    return ''.join(binary)

def crc(data, poly):
    # Add trailing zeros for CRC calculation
    data += '0' * (len(poly) - 1)
    data = list(data)  # Convert to list for mutability

    for i in range(len(data) - len(poly) + 1):
        if data[i] == '1':
            # XOR operation with the divisor (polynomial)
            for j in range(len(poly)):
                data[i + j] = '0' if data[i + j] == poly[j] else '1'

    # Extract remainder (CRC)
    return ''.join(data[-(len(poly) - 1):])

def sender():
    print("Sender Side:")
    dataword = input("Enter dataword (binary): ")
    poly = input("Enter polynomial (binary or e.g., x^4 + x^2 + 1): ")
    
    divisor = parse_polynomial(poly)
    crc_value = crc(dataword, divisor)
    codeword = dataword + crc_value

    print(f"Divisor: {divisor} ({'binary format' if all(c in '01' for c in poly) else poly})")
    print(f"CRC: {crc_value}")
    print(f"Codeword: {codeword}")

    return codeword, divisor

def receiver(codeword, divisor):
    print("\nReceiver Side:")
    syndrome = crc(codeword, divisor)

    print(f"Codeword: {codeword}")
    print(f"Divisor: {divisor}")
    print(f"Syndrome: {syndrome}")
    print("No error detected." if syndrome == '0' * (len(divisor) - 1) else "Error detected.")

if __name__ == "__main__":
    codeword, divisor = sender()
    receiver(codeword, divisor)
