# def bit_stuffing(data):
#     stuffed_data = ""
#     count = 0

#     for bit in data:
#         if bit == '1':
#             count += 1
#         else:
#             count = 0
#         stuffed_data += bit
#         if count == 5:  # Insert a '0' after five consecutive '1's
#             stuffed_data += '0'
#             count = 0

#     return stuffed_data

# def bit_destuffing(stuffed_data):
#     destuffed_data = ""
#     count = 0

#     for bit in stuffed_data:
#         if bit == '1':
#             count += 1
#         else:
#             count = 0
#         destuffed_data += bit
#         if count == 5:  # Skip the next bit (stuffed '0') after five consecutive '1's
#             count = 0
#             continue

#     return destuffed_data

# if __name__ == "__main__":
#     # User input
#     data = input("Enter binary data: ")
#     x=data

#     # Validate the input
#     if not set(data).issubset({'0', '1'}):
#         print("Error: Input must be binary data (only '0's and '1's).")
#     else:
#         # Perform bit stuffing
#         stuffed = bit_stuffing(data)
#         print("Bit-stuffed data:", stuffed)

#         # Perform bit destuffing
#         destuffed = bit_destuffing(stuffed)
#         print("Bit-destuffed data:", destuffed)

#         # Verify correctness
#         if destuffed == x:
#             print("Bit destuffing successful. Original data matches destuffed data.")
#         else:
#             print("Bit destuffing successful. Original data matches destuffed data.")
def bit_stuffing(data):
    stuffed_data = ""
    count = 0

    for bit in data:
        if bit == '1':
            count += 1
        else:
            count = 0
        stuffed_data += bit
        if count == 5:  # Insert a '0' after five consecutive '1's
            stuffed_data += '0'
            count = 0

    return stuffed_data

def bit_destuffing(stuffed_data):
    destuffed_data = ""
    count = 0

    i = 0
    while i < len(stuffed_data):
        if stuffed_data[i] == '1':
            count += 1
        else:
            count = 0
        destuffed_data += stuffed_data[i]

        if count == 5:  # Skip the next bit (stuffed '0') after five consecutive '1's
            i += 1  # Skip the stuffed bit
            count = 0

        i += 1

    return destuffed_data

def add_frame_delimiters(frames, frame_delimiter="01111110"):
    framed_data = []
    for frame in frames:
        framed_data.append(frame_delimiter + frame + frame_delimiter)
    return framed_data

def process_frames(data, frame_size):
    frames = [data[i:i+frame_size] for i in range(0, len(data), frame_size)]
    return frames

if __name__ == "__main__":
    # Read input from file
    file_name = input("Enter the input file name: ")
    
    try:
        with open(file_name, 'r') as file:
            data = file.read().strip()

        # Validate the input
        if not set(data).issubset({'0', '1'}):
            print("Error: Input must be binary data (only '0's and '1's).")
        else:
            frame_size = 10
            print(f"Original Data: {data}")

            # Split data into frames
            frames = process_frames(data, frame_size)
            print(f"Data split into frames of size {frame_size}: {frames}")

            # Add frame delimiters (01111110) to each frame
            framed_data = add_frame_delimiters(frames)
            print(f"Data with frame delimiters added: {framed_data}")

            # Perform bit stuffing for each frame
            stuffed_frames = [bit_stuffing(frame) for frame in framed_data]
            print("Bit-stuffed frames:", stuffed_frames)

            # Perform bit destuffing for each frame
            destuffed_frames = [bit_destuffing(frame) for frame in stuffed_frames]
            print("Bit-destuffed frames:", destuffed_frames)

            # Remove frame delimiters after destuffing
            destuffed_data = [frame[8:-8] for frame in destuffed_frames]  # Remove "01111110" from both ends
            print("Data after removing frame delimiters:", destuffed_data)

            # Reconstruct the original data
            reconstructed_data = ''.join(destuffed_data)
            print("Reconstructed data:", reconstructed_data)

            # Verify correctness
            if reconstructed_data == data:
                print("Bit destuffing successful. Original data matches destuffed data.")
            else:
                print("Bit destuffing failed. Original data does not match destuffed data.")

    except FileNotFoundError:
        print("Error: File not found. Please provide a valid file name.")
