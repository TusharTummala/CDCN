class ThreeAddressCodeGenerator:
    def __init__(self, expression):
        self.expression = expression.replace(" ", "")  # Remove whitespace
        self.temp_counter = 0
        self.tac = []

    def generate_temp(self):
        """Generate a new temporary variable."""
        self.temp_counter += 1
        return f"t{self.temp_counter}"

    def precedence(self, operator):
        """Return precedence of operators."""
        if operator in ['+', '-']:
            return 1
        elif operator in ['*', '/']:
            return 2
        elif operator == '^':
            return 3
        return 0

    def is_operator(self, char):
        """Check if a character is an operator."""
        return char in ['+', '-', '*', '/', '^']

    def infix_to_postfix(self):
        """Convert infix expression to postfix (RPN)."""
        stack = []
        postfix = []
        for char in self.expression:
            if char.isalnum():  # Operand
                postfix.append(char)
            elif char == '(':
                stack.append(char)
            elif char == ')':
                while stack and stack[-1] != '(':
                    postfix.append(stack.pop())
                stack.pop()  # Remove '('
            else:  # Operator
                while stack and self.precedence(stack[-1]) >= self.precedence(char):
                    postfix.append(stack.pop())
                stack.append(char)

        while stack:
            postfix.append(stack.pop())

        return postfix

    def generate_tac(self):
        """Generate Three-Address Code from the expression."""
        postfix = self.infix_to_postfix()
        stack = []

        for token in postfix:
            if token.isalnum():  # Operand
                stack.append(token)
            elif self.is_operator(token):  # Operator
                op2 = stack.pop()
                op1 = stack.pop()
                temp = self.generate_temp()
                self.tac.append(f"{temp} = {op1} {token} {op2}")
                stack.append(temp)

        return self.tac

    def display_tac(self):
        """Display the generated TAC."""
        print("Three-Address Code:")
        for line in self.tac:
            print(line)


# Test Cases
if __name__ == "__main__":
    expression = "(a + b) * (c - d)"
    print(f"Expression: {expression}")
    generator = ThreeAddressCodeGenerator(expression)
    generator.generate_tac()
    generator.display_tac()

    print("\nAnother Test Case:")
    expression2 = "x + y * z - w"
    print(f"Expression: {expression2}")
    generator2 = ThreeAddressCodeGenerator(expression2)
    generator2.generate_tac()
    generator2.display_tac()
