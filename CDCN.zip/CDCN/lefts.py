# class Grammar:
#     def __init__(self, rules):
#         self.rules = rules  # Dictionary of rules (e.g., {'A': ['Aa', 'b']})

#     def eliminate_left_recursion(self):
#         new_rules = {}
#         for non_terminal in self.rules:
#             alpha = []  # For direct left recursion (A -> Aα)
#             beta = []   # For other rules (A -> β)
#             for production in self.rules[non_terminal]:
#                 if production.startswith(non_terminal):  # Left recursion
#                     alpha.append(production[len(non_terminal):])
#                 else:
#                     beta.append(production)

#             if alpha:  # If there is left recursion
#                 new_non_terminal = non_terminal + "'"
#                 new_rules[non_terminal] = [b + new_non_terminal for b in beta]
#                 new_rules[new_non_terminal] = [a + new_non_terminal for a in alpha] + ['ε']
#             else:  # No left recursion
#                 new_rules[non_terminal] = self.rules[non_terminal]
#         self.rules = new_rules

#     def perform_left_factoring(self):
#         new_rules = {}
#         for non_terminal, productions in self.rules.items():
#             prefix_map = {}
#             for production in productions:
#                 prefix = production[0]  # Group by first character
#                 if prefix not in prefix_map:
#                     prefix_map[prefix] = []
#                 prefix_map[prefix].append(production)

#             # If multiple productions share the same prefix, perform factoring
#             factored_rules = []
#             for prefix, group in prefix_map.items():
#                 if len(group) > 1:
#                     new_non_terminal = non_terminal + "'"
#                     new_rules[new_non_terminal] = [prod[1:] if len(prod) > 1 else 'ε' for prod in group]
#                     factored_rules.append(prefix + new_non_terminal)
#                 else:
#                     factored_rules.extend(group)
#             new_rules[non_terminal] = factored_rules
#         self.rules = new_rules

#     def __str__(self):
#         return "\n".join(f"{nt} -> {' | '.join(productions)}" for nt, productions in self.rules.items())


# # Test cases
# if __name__ == "__main__":
#     print("\nTest Case 3: Both Eliminate Left Recursion and Perform Left Factoring")
#     # Sample Input: {'S': ['Sa', 'Sb', 'c', 'd']}
#     inputgrammar=input()
#     grammar3 = Grammar(input_grammar())  # User inputs grammar here
#     print("Original Grammar:")
#     print(grammar3)
#     grammar3.eliminate_left_recursion()
#     grammar3.perform_left_factoring()
#     print("\nAfter Processing:")
#     print(grammar3)



class Grammar:
    def __init__(self, rules):
        self.rules = rules  # Dictionary of rules (e.g., {'A': ['Aa', 'b']})

    def eliminate_left_recursion(self):
        new_rules = {}
        for non_terminal in self.rules:
            alpha = []  # For direct left recursion (A -> Aα)
            beta = []   # For other rules (A -> β)
            for production in self.rules[non_terminal]:
                if production.startswith(non_terminal):  # Left recursion
                    alpha.append(production[len(non_terminal):])
                else:
                    beta.append(production)

            if alpha:  # If there is left recursion
                new_non_terminal = non_terminal + "'"
                new_rules[non_terminal] = [b + new_non_terminal for b in beta]
                new_rules[new_non_terminal] = [a + new_non_terminal for a in alpha] + ['ε']
            else:  # No left recursion
                new_rules[non_terminal] = self.rules[non_terminal]
        self.rules = new_rules

    def perform_left_factoring(self):
        new_rules = {}
        for non_terminal, productions in self.rules.items():
            prefix_map = {}
            for production in productions:
                prefix = production[0]  # Group by first character
                if prefix not in prefix_map:
                    prefix_map[prefix] = []
                prefix_map[prefix].append(production)

            # If multiple productions share the same prefix, perform factoring
            factored_rules = []
            for prefix, group in prefix_map.items():
                if len(group) > 1:
                    new_non_terminal = non_terminal + "'"
                    new_rules[new_non_terminal] = [prod[1:] if len(prod) > 1 else 'ε' for prod in group]
                    factored_rules.append(prefix + new_non_terminal)
                else:
                    factored_rules.extend(group)
            new_rules[non_terminal] = factored_rules
        self.rules = new_rules

    def __str__(self):
        return "\n".join(f"{nt} -> {' | '.join(productions)}" for nt, productions in self.rules.items())


# Function to input grammar as a string
def input_grammar():
    grammar_str = input("Enter grammar rules as a string (e.g., 'A->Aa|b, B->c|d'): ").strip()
    rules = {}
    # Split by commas to separate non-terminals
    for rule in grammar_str.split(','):
        non_terminal, productions = rule.split('->')
        productions = productions.split('|')  # Split productions by '|'
        rules[non_terminal.strip()] = [prod.strip() for prod in productions]
    return rules


if __name__ == "__main__":
    print("Enter grammar in the format: NonTerminal->Production1|Production2,...")
    grammar_rules = input_grammar()  # User inputs grammar here
    
    # Create a Grammar object with the inputted rules
    grammar = Grammar(grammar_rules)
    
    print("\nOriginal Grammar:")
    print(grammar)
    
    # Eliminate left recursion
    grammar.eliminate_left_recursion()
    
    # Perform left factoring
    grammar.perform_left_factoring()
    
    print("\nAfter Eliminating Left Recursion and Performing Left Factoring:")
    print(grammar)
